import React, { useState, useEffect } from 'react';
import {
  BarChart2,
  Users,
  ListTodo,
  LayoutGrid,
  Table,
  Calendar,
  CalendarClock,
  UserPlus,
  LogOut,
  ChevronRight,
  Shield,
  Mail,
  ClipboardCheck,
} from 'lucide-react';
import BrandLogo from './BrandLogo';
import { useAuth, isStaffDeleted } from '../context/AuthContext';

export default function Sidebar({ activeTab, setActiveTab, companyName, taskBadgeCount, onOpenStaffModal }) {
  const { isOwner, isStaff, profile, signOut, getTeamMembers } = useAuth();
  const [staffList, setStaffList] = useState(() => {
    try {
      const ownerKey = profile?.id ? `crm_local_staff_${profile.id}` : null;
      if (ownerKey) {
        const cached = JSON.parse(localStorage.getItem(ownerKey) || '[]');
        if (Array.isArray(cached) && cached.length > 0) {
          return cached.filter((m) => m.persona !== 'owner' && !isStaffDeleted(m));
        }
      }
    } catch {}
    return [];
  });

  const reloadStaff = () => {
    if (isOwner && getTeamMembers) {
      getTeamMembers()
        .then((members) => {
          if (Array.isArray(members)) {
            const staff = members.filter((m) => m.persona !== 'owner' && !isStaffDeleted(m));
            setStaffList(staff);
          }
        })
        .catch(() => {});
    }
  };

  useEffect(() => {
    reloadStaff();
    window.addEventListener('crm_staff_updated', reloadStaff);
    return () => window.removeEventListener('crm_staff_updated', reloadStaff);
  }, [isOwner, profile?.id, getTeamMembers]);

  const userPerms = profile?.permissions || {};
  // Strict permission enforcement: staff only sees sections owner explicitly granted
  const canViewAnalytics = isOwner ? true : Boolean(userPerms.view_analytics);
  const canViewLeads = isOwner ? true : (userPerms.view_leads !== false);
  const canViewTasks = isOwner ? true : Boolean(userPerms.view_tasks);
  const canViewActivity = isOwner ? true : Boolean(userPerms.view_activity);
  const canViewOutreach = isOwner ? true : Boolean(userPerms.view_outreach);
  const canViewMyDays = isOwner ? true : Boolean(userPerms.view_mydays);
  const canViewFollowUp = isOwner ? true : Boolean(userPerms.view_followup);

  const rawNavItems = [
    { id: 'analytics', label: isStaff ? 'My Analytics' : 'Analytics', icon: BarChart2, visible: canViewAnalytics },
    { id: 'leads', label: isStaff ? 'My Leads' : 'Leads', icon: Users, visible: canViewLeads },
    { id: 'tasks', label: isStaff ? 'My Tasks' : 'Task Management', icon: ListTodo, badge: true, visible: canViewTasks },
    { id: 'activity', label: 'Activity', icon: LayoutGrid, visible: canViewActivity },
    { id: 'outreach', label: 'Outreach', icon: Table, visible: canViewOutreach },
    { id: 'mydays', label: 'My Days', icon: Calendar, visible: canViewMyDays },
    { id: 'followup', label: 'Follow up', icon: CalendarClock, visible: canViewFollowUp },
    { id: 'review', label: isStaff ? 'My Performance' : 'Team Review', icon: ClipboardCheck },
    { id: 'email', label: 'Email Marketing', icon: Mail, visible: isOwner, pro: true },
  ];

  const navItems = rawNavItems.filter((item) => item.visible !== false);

  return (
    <aside className="hidden md:flex md:w-64 md:fixed md:inset-y-0 md:left-0 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 z-30 flex-col border-r border-slate-200 dark:border-slate-800 select-none shadow-sm">
      {/* Brand Header with Logo Colors */}
      <div className="p-5 flex items-center gap-3 border-b border-slate-100 dark:border-slate-800">
        <BrandLogo size={32} />
        <div className="min-w-0">
          <div className="text-base font-extrabold text-slate-900 dark:text-white truncate tracking-tight flex items-center gap-1.5">
            <span>{companyName || 'My Organization'}</span>
          </div>
          <div className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
            <span>Export & Trade CRM</span>
            {isStaff ? (
              <span className="px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-[9px] font-bold text-slate-600">
                STAFF
              </span>
            ) : (
              <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 text-[9px] font-bold">
                OWNER
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
          {isStaff ? 'My Workspace' : 'Sales & Operations'}
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          const showBadge = item.badge && taskBadgeCount > 0;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center justify-between w-full px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 cursor-pointer ${isActive
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold border-l-4 border-emerald-500 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  size={18}
                  className={isActive ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400 group-hover:text-slate-600'}
                />
                <span>{item.label}</span>
              </div>

              {showBadge ? (
                <span className="px-2 py-0.5 text-xs font-bold text-white bg-[#F88F61] rounded-full shadow-sm">
                  {taskBadgeCount}
                </span>
              ) : item.pro ? (
                <span className="px-1.5 py-0.5 text-[9px] font-black uppercase rounded-md bg-amber-100 text-amber-800 border border-amber-200">
                  Pro
                </span>
              ) : isActive ? (
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
              ) : null}
            </button>
          );
        })}

        {/* Owner Controls: Team & Staff Management */}
        {isOwner && (
          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <div className="px-3 pb-0.5 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center justify-between">
              <span>Organization</span>
              <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                Owner
              </span>
            </div>

            <button
              onClick={() => onOpenStaffModal && onOpenStaffModal()}
              className="flex items-center justify-between w-full px-3 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-sm shadow-emerald-600/20 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2">
                <UserPlus size={15} />
                <span>+ Create Staff</span>
              </div>
              <span className="text-[10px] bg-emerald-700/80 px-1.5 py-0.5 rounded text-white font-extrabold">Add</span>
            </button>

            {/* Owner Employee Roster & Count */}
            <div className="bg-slate-50/90 dark:bg-slate-800/60 rounded-xl p-2.5 border border-slate-200/80 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between px-1 text-[11px] font-bold text-slate-700 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Users size={13} className="text-emerald-600 dark:text-emerald-400" />
                  <span>Employees ({staffList.length})</span>
                </span>
                <span className="text-[9px] font-extrabold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/70 px-1.5 py-0.5 rounded-md">
                  {staffList.filter((s) => s.is_active !== false).length} Active
                </span>
              </div>

              {staffList.length === 0 ? (
                <div className="px-2 py-2 text-[10px] text-slate-400 text-center italic">
                  No staff accounts yet. Click above to add staff.
                </div>
              ) : (
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-0.5">
                  {staffList.map((st) => (
                    <div
                      key={st.id}
                      className="flex items-center justify-between p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 text-[11px] hover:border-emerald-400 dark:hover:border-emerald-600 transition-all shadow-2xs group"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <img
                          src={st.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=60&auto=format&fit=crop&q=80'}
                          alt={st.name}
                          className="w-6 h-6 rounded-full object-cover shrink-0 ring-1 ring-slate-200 dark:ring-slate-700"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 dark:text-white truncate leading-tight flex items-center gap-1">
                            <span className="truncate">{st.name}</span>
                            {st.is_active === false && (
                              <span className="text-[8px] text-rose-500 font-bold">Paused</span>
                            )}
                          </div>
                          <div className="text-[9px] text-slate-400 truncate leading-tight">
                            {st.department || st.email}
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => onOpenStaffModal && onOpenStaffModal(st)}
                        className="px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 rounded-md border border-emerald-200 dark:border-emerald-800 shrink-0 cursor-pointer transition-all shadow-2xs"
                        title="Edit Permissions & Scope"
                      >
                        Edit
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </nav>

      {/* Footer / Logged In Role Banner & Prominent Logout */}
      <div className="p-3.5 border-t border-slate-100 dark:border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-bold text-slate-700 dark:text-slate-300 truncate max-w-[125px]">
              {profile?.name || 'Online'}
            </span>
          </div>
          <span className="font-mono text-[10px] font-bold px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded text-slate-600">
            {isOwner ? 'Owner' : 'Staff'}
          </span>
        </div>
        <button
          type="button"
          onClick={signOut}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/40 border border-rose-200/80 dark:border-rose-900/60 shadow-xs transition-all cursor-pointer"
        >
          <LogOut size={13} />
          <span>Sign Out / Logout</span>
        </button>
      </div>
    </aside>
  );
}
