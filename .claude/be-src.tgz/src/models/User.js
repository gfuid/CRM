const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    id: { type: String, unique: true, index: true },
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, default: '' },
    role: { type: String, enum: ['admin', 'manager', 'agent'], default: 'agent' },
    persona: { type: String, enum: ['owner', 'staff'], default: 'staff' },
    department: { type: String, default: 'Sales' },
    phone: { type: String, default: '' },
    is_active: { type: Boolean, default: true },
    avatar_url: { type: String, default: '' },
    data_scope: { type: String, enum: ['own_only', 'all'], default: 'own_only' },
    permissions: { type: mongoose.Schema.Types.Mixed, default: {} },
    company_id: { type: String, default: '' },
    created_by: { type: String, default: '' },
    staff_limit: { type: Number, default: 2 },
    last_login: { type: Date, default: Date.now },
    created_at: { type: Date, default: Date.now },
  },
  {
    strict: false,
    timestamps: true,
    toJSON: {
      transform: (doc, ret) => {
        delete ret.password;
        delete ret.__v;
        return ret;
      },
    },
  }
);

// Hash password before saving if modified and not already hashed
userSchema.pre('save', async function () {
  if (!this.isModified('password') || !this.password) {
    return;
  }
  // Prevent double hashing if already a bcrypt hash
  if (this.password.startsWith('$2a$') || this.password.startsWith('$2b$')) {
    return;
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// Compare candidate password
userSchema.methods.comparePassword = async function (candidatePassword) {
  if (!this.password) return false;
  return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
